package songcurdapp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Song {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String Artistic;
	private String Song;
	private String DateofRealese;
	private String Rating;

	public Song(String artistic, String song, String dateofRealese, String rating) {
		super();
		Artistic = artistic;
		Song = song;
		DateofRealese = dateofRealese;
		Rating = rating;
	}
	public Song() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getArtistic() {
		return Artistic;
	}
	public void setArtistic(String artistic) {
		Artistic = artistic;
	}
	public String getSong() {
		return Song;
	}
	public void setSong(String song) {
		Song = song;
	}
	public String getDateofRealese() {
		return DateofRealese;
	}
	public void setDateofRealese(String dateofRealese) {
		DateofRealese = dateofRealese;
	}
	public String getRating() {
		return Rating;
	}
	public void setRating(String rating) {
		Rating = rating;
	}
	@Override
	public String toString() {
		return "Song [Artistic=" + Artistic + ", Song=" + Song + ", DateofRealese=" + DateofRealese + ", Rating="
				+ Rating + "]";
	}
	
}
